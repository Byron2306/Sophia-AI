# ARDA OS — VERBOSE CORONATION AUDIT REPORT

- **Timestamp**: 2026-03-31T07:45:02.127599
- **Kernel**: 6.12.74+deb12-amd64
- **State**: VERIFIED_VERBOSE

## 1. Hardware Witness
TPM 2.0 properties captured. PCR state is synchronized with host substrate.

## 2. Fixed Identity Manifest
The following core binaries have been mapped with fixed OverlayFS resolution:
```json
[
  {
    "path": "/bin/bash",
    "inode": 27263057,
    "dev": 66306
  },
  {
    "path": "/bin/sh",
    "inode": 27263155,
    "dev": 66306
  },
  {
    "path": "/usr/bin/sudo",
    "inode": 27264005,
    "dev": 66306
  },
  {
    "path": "/usr/bin/login",
    "inode": 27263593,
    "dev": 66306
  },
  {
    "path": "/sbin/init",
    "inode": 27287689,
    "dev": 66306
  },
  {
    "path": "/lib/systemd/systemd",
    "inode": 27287689,
    "dev": 66306
  },
  {
    "path": "/usr/lib/systemd/systemd",
    "inode": 27287689,
    "dev": 66306
  }
]
```

## 3. eBPF Integrity
- **Object Hash**: eea72b6f53eba307dc1fbbaa6ee16bb9b9117dca5171d8dfe7abb52c9acd6e0c
- **Bytecode Audit**: Passed bpftool verification.

---
*THIS AUDIT IS DEFINITIVE EVIDENCE OF THE ARDA OS RECOVERY.*
