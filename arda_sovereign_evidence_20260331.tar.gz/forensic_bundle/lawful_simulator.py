#!/usr/bin/env python3
import json

# ARDA OS: Sovereign Logic Mirror
# Matches the logic in arda_physical_lsm.c exactly.

HARMONY_MAP = {
    # (inode, dev)
    (27263057, 66306): "bash",
    (27263155, 66306): "sh",
    (27264005, 66306): "sudo"
}

STATE_MAP = {0: 1} # 1 = ENFORCED, 0 = AUDIT

def simulate_enforcement(path, inode, dev):
    state = STATE_MAP.get(0, 0)
    print(f"CHECKING: {path} (Inode: {inode}, Dev: {dev})")
    
    if state == 0:
        print("  STATE: AUDIT (0) -> ALLOW (Log Only)")
        return 0 # ALLOW
        
    identity = (inode, dev)
    if identity in HARMONY_MAP:
        print(f"  IDENTITY: {HARMONY_MAP[identity]} -> HARMONIC -> ALLOW")
        return 0 # ALLOW
    else:
        print(f"  IDENTITY: UNKNOWN -> DISSONANT -> DENY (EPERM)")
        return -1 # EPERM

if __name__ == "__main__":
    print("--- ARDA OS: SOVEREIGN LOGIC MIRROR TEST ---")
    
    # CASE 1: Authorized (Harmonic)
    print("\n[TEST 1: AUTHORIZED BINARY]")
    res1 = simulate_enforcement("/bin/bash", 27263057, 66306)
    
    # CASE 2: Unauthorized (Dissonant)
    print("\n[TEST 2: UNAUTHORIZED BINARY]")
    res2 = simulate_enforcement("/tmp/evil_binary", 99999999, 12345)
    
    print("\n--- RESULTS ---")
    print(f"Authorized Execution: {'SUCCESS' if res1 == 0 else 'FAILURE'}")
    print(f"Unauthorized Execution: {'EPERM (LAWFULLY DENIED)' if res2 == -1 else 'FAILURE'}")
