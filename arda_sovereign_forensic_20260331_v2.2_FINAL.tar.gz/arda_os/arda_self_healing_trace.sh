#!/bin/bash
set -e
TRACE_LOG="/home/byron/Integritas-Mechanicus-clean/Integritas-Mechanicus/arda_self_healing_trace.log"
echo "--- ARDA OS SOVEREIGN TRACE START: $(date -u) ---" > "$TRACE_LOG"
echo "[1] PROVING FRACTURE: Clearing Harmony Map..." | tee -a "$TRACE_LOG"
MAP_ID=$(sudo bpftool map show | grep arda_harmony | cut -d: -f1)
if [ -n "$MAP_ID" ]; then
    INODE=$(stat -c %i /bin/bash)
    DEV=$(stat -c %d /bin/bash)
    KEY_HEX=$(printf "%016x%016x" $INODE $DEV | sed 's/\(..\)/0x\1 /g')
    sudo bpftool map delete id $MAP_ID key $KEY_HEX || true
    echo "Current Map State (Fractured):" >> "$TRACE_LOG"
    sudo bpftool map dump id $MAP_ID >> "$TRACE_LOG"
fi
echo -e "\n[2] TRIGGERING RESTORATION: Running RECOVER_ARDA.py..." | tee -a "$TRACE_LOG"
sudo python3 /home/byron/Integritas-Mechanicus-clean/Integritas-Mechanicus/RECOVER_ARDA.py >> "$TRACE_LOG" 2>&1
echo -e "\n[3] VERIFYING MEND: Checking Harmony Map..." | tee -a "$TRACE_LOG"
MAP_ID=$(sudo bpftool map show | grep arda_harmony | cut -d: -f1)
sudo bpftool map dump id $MAP_ID | grep -q "0x" && echo "SUCCESS: Map Populated." | tee -a "$TRACE_LOG"
echo -e "\n--- ARDA OS SOVEREIGN TRACE END ---" | tee -a "$TRACE_LOG"
