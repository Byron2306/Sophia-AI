import json
import subprocess
import struct
import sys

def seed():
    # Run the existing seeder to get the JSON
    result = subprocess.run(['sudo', 'python3', '/home/byron/Integritas-Mechanicus-clean/Integritas-Mechanicus/arda_os/backend/services/arda_seeder.py'], capture_output=True, text=True)
    try:
        # Strip trailing "ARDA OS: FIXED SEEDER ACTIVE" line if present
        json_str = result.stdout.split('\n', 1)[1] if "FIXED SEEDER ACTIVE" in result.stdout else result.stdout
        binaries = json.loads(json_str)
    except Exception as e:
        print(f"Error parsing seeder JSON: {e}")
        return

    # Find Map ID
    res = subprocess.run(['sudo', 'bpftool', 'map', 'show'], capture_output=True, text=True)
    map_id = None
    for line in res.stdout.split('\n'):
        if 'arda_harmony' in line:
            map_id = line.split(':')[0].strip()
            break
    
    if not map_id:
        print("Error: arda_harmony map not found.")
        return

    print(f"Seeding Map ID: {map_id}")
    for b in binaries:
        inode = int(b['inode'])
        dev = int(b['dev'])
        # Key: 8 bytes inode, 8 bytes dev (little-endian)
        key_bytes = struct.pack('<QQ', inode, dev)
        key_hex = " ".join(f"0x{b:02x}" for b in key_bytes)
        
        # Value: 4 bytes (e.g., 1)
        value_hex = "0x01 0x00 0x00 0x00"
        
        cmd = f"sudo bpftool map update id {map_id} key {key_hex} value {value_hex}"
        subprocess.run(cmd.split(), check=True)
        print(f"Seeded: {b['path']} (Inode: {inode}, Dev: {dev})")

if __name__ == "__main__":
    seed()
